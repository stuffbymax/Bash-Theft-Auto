1. some jobs doesnt have sfx yet
2. The Pistol gives a \e[1;32m+5%%\e[0m success chance. (looks like bad coloring syntax)
