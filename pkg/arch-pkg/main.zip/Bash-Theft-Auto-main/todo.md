1. Ammunition and Usable Items (especially the Health Pack)

2. Vehicle Selling is a logical addition.

3. Gambling , especially for Las Venturas.

4. Property and Time Cycle 

# every time
 
- Testing. Test for bugs and issues.
    
    
