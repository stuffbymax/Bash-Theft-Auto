
1. add radio [completed] 

1.2 fix save function [completed]

1.3 complete the save function dir  [completed]

2. Skill System: This adds a sense of character progression. [semi completed]

3. Reputation System: This can make the world more dynamic.

4. Item Usage: Makes items more meaningful.

5. Dynamic Events: Provides more engaging gameplay.

6. More Job Variety: More options for the player.

7. Vehicle System Add another layer of complexity.

8. Configuration Files: Makes it easier to tweak and modify. [thechnicaly do to better save functions is easier tomodify]

9. Advanced Input Handling: Polishes the user experience.

10. Code Refactoring: Clean up and organise. [completed]

11. add animations [Completed need update tho]

12. add sfx [code added but only some sfx ] 

# every time
 
- Testing. Test for bugs and issues.
    
    
