sidequesting - cash_register.wav https://freesound.org/people/sidequesting/sounds/542568/
gun-shot - Sound Effect by Alice_soundz from Pixabay
mechanic (original is called sabotash)- Sound Effect by karim nessim from Pixabay
security (original isairport-security-message-bills-stereo-compressed-34519 )- Sound Effect by freesound_community from Pixabay
win - Sound Effect by floraphonic from Pixabay
lose (Losing Horn)- Sound Effect by u_l5xum8z250 from Pixabay

