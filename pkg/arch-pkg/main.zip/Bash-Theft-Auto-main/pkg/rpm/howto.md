### 1. Build the RPM
```
rpmbuild -ba bash-theft-auto.spec
```

### 2. Install the package
```
sudo dnf install /pkg/rpm/RPMS/noarch/bash-theft-auto-2.0.1-1.noarch.rpm
```
